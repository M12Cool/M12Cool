<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">
            @yield('page_title', 'Dashboard')
            <small>@yield('page_title_small', '')</small>
        </h1>
    </div>
</div>